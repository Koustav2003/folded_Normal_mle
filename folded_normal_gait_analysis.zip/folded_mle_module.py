
import numpy as np

def simulate_folded_normal(mu, sigma, size):
    return np.abs(np.random.normal(loc=mu, scale=sigma, size=size))

def simulate_standard_mle(data):
    return np.mean(data)

def simulate_penalized_mle(data, penalty=0.05):
    mu_hat = np.mean(data) - penalty
    return max(mu_hat, 0)

def simulate_hausdorff_mle(data, noise=0.015):
    mu_hat = np.mean(data) + np.random.normal(0, noise)
    return max(mu_hat, 0)

def bootstrap_ci(data, B=200, alpha=0.05):
    n = len(data)
    boot_means = []
    for _ in range(B):
        sample = np.random.choice(data, size=n, replace=True)
        mu_b = np.mean(sample) + np.random.normal(0, 0.015)
        boot_means.append(mu_b)
    lower = np.percentile(boot_means, 100 * alpha / 2)
    upper = np.percentile(boot_means, 100 * (1 - alpha / 2))
    return lower, upper
